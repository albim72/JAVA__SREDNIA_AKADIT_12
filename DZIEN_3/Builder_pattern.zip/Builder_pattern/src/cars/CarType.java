package cars;

public enum CarType {
    CITY_CAR,SPORTS_CAR,SUV
}
